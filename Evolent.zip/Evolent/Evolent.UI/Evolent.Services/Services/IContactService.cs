﻿using Evolent.Models.ServiceModels;
using Evolent.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace Evolent.Services.Services
{
    public interface IContactService
    {
        /// <summary>
        /// Method delecration for get contact list
        /// </summary>
        /// <param name="searchContactModel"></param>
        /// <returns></returns>
        ViewResponseModel<ContactLstServiceModel> List(SearchContactModel searchContactModel);
        /// <summary>
        /// Method declration for get contact details
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        ViewResponseModel<ContactModel> Get(long id);
        /// <summary>
        /// Method declration for add/update contact
        /// </summary>
        /// <param name="contactModel"></param>
        /// <returns></returns>
        ViewResponseModel<long> AddUpdate(ContactModel contactModel);
        /// <summary>
        /// Method declration for delete contact
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        ViewResponseModel<bool> Delete(long id);
    }
}
