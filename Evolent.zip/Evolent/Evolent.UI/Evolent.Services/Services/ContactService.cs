﻿
using Evolent.Models.ServiceModels;
using Evolent.Models.ViewModels;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;

namespace Evolent.Services.Services
{
    /// <summary>
    /// Contact service class for basic curd opration
    /// like add/edit/delete/list
    /// </summary>
    public class ContactService : IContactService
    {
        readonly string DataServiceUrl;
        public ContactService()
        {
            DataServiceUrl = Environment.GetEnvironmentVariable("DataServiceUrl");
        }
        /// <summary>
        /// Get contact list method defination
        /// </summary>
        /// <param name="searchContactModel"></param>
        /// <returns></returns>
        public ViewResponseModel<ContactLstServiceModel> List(SearchContactModel searchContactModel)
        {
            ViewResponseModel<ContactLstServiceModel> ViewResponse = new ViewResponseModel<ContactLstServiceModel>();
            try
            {

                using (var client = new HttpClient())
                {
                    HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, $"{DataServiceUrl}/list");
                    httpRequestMessage.Content = new StringContent(JsonConvert.SerializeObject(searchContactModel), Encoding.UTF8, "application/json");
                    var response = client.SendAsync(httpRequestMessage).Result;
                    var data = response.Content.ReadAsStringAsync();
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        APIResponse<ContactLstServiceModel> apiResponse = JsonConvert.DeserializeObject<APIResponse<ContactLstServiceModel>>(data.Result);
                        ViewResponse.Response = apiResponse.Response;
                        ViewResponse.Message = "Contact list featched successfully";
                        ViewResponse.IsSuccess = true;
                        return ViewResponse;
                    }
                    else if (response.StatusCode == HttpStatusCode.NoContent)
                    {
                        ViewResponse.IsSuccess = false;
                        ViewResponse.Message = "No data found";

                        //Log status code and message 
                    }
                    else if (response.StatusCode == HttpStatusCode.BadRequest)
                    {
                        ViewResponse.IsSuccess = false;
                        ViewResponse.Message = "Invalid request";

                    }
                    else
                    {
                        ViewResponse.IsSuccess = false;
                        ViewResponse.Message = "Error occored while getting contact details";
                        //Log status code and message 
                    }
                }
                return ViewResponse;
            }
            catch (Exception ex)
            {

                //Log exception
                ViewResponse.IsSuccess = false;
                ViewResponse.Message = "Error occored while feaching contact list";
                return ViewResponse;
            }
        }
		/// <summary>
		/// GEt contact detail method defination
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		public ViewResponseModel<ContactModel> Get(long id)
        {
            ViewResponseModel<ContactModel> ViewResponse = new ViewResponseModel<ContactModel>();

            try
            {
                using (var client = new HttpClient())
                {
                    HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, $"{DataServiceUrl}/get?id={id}");
                    var response = client.SendAsync(httpRequestMessage).Result;
                    var data = response.Content.ReadAsStringAsync();
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        APIResponse<ContactModel> apiResponse = JsonConvert.DeserializeObject<APIResponse<ContactModel>>(data.Result);
                        ViewResponse.IsSuccess = true;
                        ViewResponse.Message = apiResponse.Message;
                        ViewResponse.Response = apiResponse.Response;

                    }
                    else if (response.StatusCode == HttpStatusCode.NotFound)
                    {
                        ViewResponse.IsSuccess = false;
                        ViewResponse.Message = "No contact found";

                        //Log status code and message 
                    }
                    else if (response.StatusCode == HttpStatusCode.BadRequest)
                    {
                        ViewResponse.IsSuccess = false;
                        ViewResponse.Message = "Invalid request";

                    }
                    else
                    {
                        ViewResponse.IsSuccess = false;
                        ViewResponse.Message = "Error occored while getting contact details";
                        //Log status code and message 
                    }

                    return ViewResponse;
                }
            }
            catch (Exception ex)
            {
                //Log exception
                ViewResponse.IsSuccess = false;
                ViewResponse.Message = "Error occored while getting contact details";
                return ViewResponse;
            }

        }
        /// <summary>
        /// Add/Update contact detail method defination
        /// </summary>
        /// <param name="contactModel"></param>
        /// <returns></returns>

        public ViewResponseModel<long> AddUpdate(ContactModel contactModel)
        {
            ViewResponseModel<long> ViewResponse = new ViewResponseModel<long>();
            try
            {

                using (var client = new HttpClient())
                {
					
					HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Post, $"{DataServiceUrl}/addupdate");
					contactModel.UserTackingId = "Evolent Test"; //Temp added still login implement

					httpRequestMessage.Content = new StringContent(JsonConvert.SerializeObject(contactModel), Encoding.UTF8, "application/json");
                    var response = client.SendAsync(httpRequestMessage).Result;
                    var data = response.Content.ReadAsStringAsync();
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        APIResponse<long> apiResponse = JsonConvert.DeserializeObject<APIResponse<long>>(data.Result);
                        ViewResponse.Response = apiResponse.Response;
                        ViewResponse.Message = apiResponse.Message;
                        ViewResponse.IsSuccess = true;
                        return ViewResponse;
                    }
                    else if (response.StatusCode == HttpStatusCode.NotFound)
                    {
                        ViewResponse.IsSuccess = false;
                        ViewResponse.Message = "No contact found to update";

                        //Log status code and message 
                    }
					else if (409 == (int)response.StatusCode)
					{
						ViewResponse.IsSuccess = false;
						ViewResponse.Message = "User already exist with same email";

						//Log status code and message 
					}
					else if (response.StatusCode == HttpStatusCode.BadRequest)
                    {
                        ViewResponse.IsSuccess = false;
                        ViewResponse.Message = "Invalid request";

                    }
                    else
                    {
                        ViewResponse.IsSuccess = false;
                        ViewResponse.Message = "Error occored while saving contact";
                        //Log status code and message 
                    }
                }
                return ViewResponse;
            }
            catch (Exception ex)
            {

                //Log exception
                ViewResponse.IsSuccess = false;
                ViewResponse.Message = "Error occored while saving contact";
                return ViewResponse;
            }
        }
        /// <summary>
        /// Method for delete contact 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        public ViewResponseModel<bool> Delete(long id)
        {
            ViewResponseModel<bool> ViewResponse = new ViewResponseModel<bool>();

            try
            {
                using (var client = new HttpClient())
                {
                    HttpRequestMessage httpRequestMessage = new HttpRequestMessage(HttpMethod.Get, $"{DataServiceUrl}/delete?id={id}");
                    var response = client.SendAsync(httpRequestMessage).Result;
                    var data = response.Content.ReadAsStringAsync();
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        APIResponse<bool> apiResponse = JsonConvert.DeserializeObject<APIResponse<bool>>(data.Result);
                        ViewResponse.IsSuccess = true;
                        ViewResponse.Message = apiResponse.Message;
                        ViewResponse.Response = apiResponse.Response;

                    }
                    else if (response.StatusCode == HttpStatusCode.NotFound)
                    {
                        ViewResponse.IsSuccess = false;
                        ViewResponse.Message = "No contact found to delete";

                        //Log status code and message 
                    }
                    else if (response.StatusCode == HttpStatusCode.BadRequest)
                    {
                        ViewResponse.IsSuccess = false;
                        ViewResponse.Message = "Invalid request";

                    }
                    else
                    {
                        ViewResponse.IsSuccess = false;
                        ViewResponse.Message = "Error occored while deletin contact";
                        //Log status code and message 
                    }

                    return ViewResponse;
                }
            }
            catch (Exception ex)
            {
                //Log exception
                ViewResponse.IsSuccess = false;
                ViewResponse.Message = "Error occored while deleting contact";
                return ViewResponse;
            }

        }

    }
}
