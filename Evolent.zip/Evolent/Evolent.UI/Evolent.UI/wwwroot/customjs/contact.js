﻿var Contact = function () {

   
    /* bind booking serach events */
    function bindContactSearchEvents() {
        
        $("#ContactPhone").keydown(function (e) {
            // Allow: backspace, delete, tab, escape, enter and .
            if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110]) !== -1 ||
                // Allow: Ctrl+C
                (e.keyCode === 67 && (e.ctrlKey === true)) ||
                // Allow: Ctrl+v
                (e.keyCode === 86 && (e.ctrlKey === true)) ||
                // Allow: Ctrl+A, Command+A
                (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                // Allow: home, end, left, right, down, up
                (e.keyCode >= 35 && e.keyCode <= 40)) {
                // let it happen, don't do anything
                return;
            }
            // Ensure that it is a number and stop the keypress
            if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                e.preventDefault();
            }
        });
        $("#ContactEmail").keyup(function (e) {
            if (e.keyCode === 13) {
                Contact.loadContactTable();
            }
        });
        $("#ContactEmail").change(function () {
            if (!validateEmail($("#ContactEmail").val())) {
                alert("Invalid contact email address.");
                $("#CustomerEmailId").val('');
            }
        });
        $('#Status').change(function () {
            if (this.checked) {
                $('#Status').val(true);
            }
            else {
                $('#Status').val(false);
            }
        });
       
    }
    function ValidateContact() {

        if ($("#FirstName").val() === '') {
            alert("Please enter name");
            return false;
        }
        if ($("#Email").val() === '') {
            alert("Please enter email");
            return false;
        }
        else if (!validateEmail($("#Email").val())) {
            alert("Invalid contact email address.");
            $("#Email").val('');
            return false;
        }
        else if (!validatePhone($("#Phone").val())) {
            alert("Invalid phone number.");
            $("#Phone").val('');
            return false;
        }
        else {
            return true;
        }
    }
    function validateEmail(Email) {
        var pattern = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        return $.trim(Email).match(pattern) ? true : false;
    }
    function validatePhone(Phone) {
        var pattern = /^[0-9-+]+$/;
        return $.trim(Phone).match(pattern) ? true : false;
    }
    return {
        init: function () {
            bindContactSearchEvents();
        },
        loadContactTable: function myfunction() {
            $("#booking-search").DataTable({
                "processing": false, // for show progress bar  
                "serverSide": true, // for process server side  
                "filter": true, // this is for disable filter (search box)  
                "orderMulti": false, // for disable multiple column at once  
                "pageLength": 20,
                "paging": true,
                "searching": false,
                "bDestroy": true,
                "bLengthChange": false,
                "pagingType": "full_numbers",
                "order": [[0, "desc"]],
                "ajax": {
                    url: "/Contact/LoadList",
                    type: "POST",
                    datatype: "json",
                    data: function (d) {
                        contactFilter = {
                            "ContactEmail": $("#ContactEmail").val(),
                            "ContactPhone": $("#ContactPhone").val(),
                        };
                        var info = $('#booking-search').DataTable().page.info();
                        return $.extend({}, d, {
                            "pageNo": info.page + 1, "filter": contactFilter
                        });
                    },
                    complete: function () {

                    },
                    error: function (jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status === 440) {
                            var callbackurl = window.location.href; window.location.href = "/Login/SignUp?key=" + callbackurl;
                        }
                    }
                },
                "columns": [
                    { "data": "contactId", "name": "Id", "autoWidth": true, "targets": 'no-sort', "orderable": false },
                    { "data": "firstName", "name": "FirstName", "autoWidth": true, "targets": 'no-sort', "orderable": false },
                    { "data": "lastName", "title": "LastName", "name": "LastName", "autoWidth": true, "targets": 'no-sort', "orderable": false },
                    { "data": "email", "title": "Email", "name": "Email", "autoWidth": true, "targets": 'no-sort', "orderable": false },
                    { "data": "phone", "title": "Phone", "name": "Phone", "autoWidth": true, "targets": 'no-sort', "orderable": false },
                    {
                        "data": function (data) {
                            var html = '';
                            if (data.status === true) {
                                html = 'Active';
                            } else {
                                html = 'Inactive';
                            }
                            return html;
                        }, "name": "Status", "autoWidth": true, "targets": 'no-sort', "orderable": false
                    },
                    {
                        "mRender": function (data, type, row) {
                            var id = row.contactId;
                            return '<a href="/Contact/AddUpdate?id=' + id + '">Edit</a> / <a href="#" data-val=' + id + ' onclick="Contact.deleteContact(' + id + ')">Delete</a>';
                        }
                    }
                ],
                dom: "<'row'<'col-sm-12'p>>" +
                    "<'row'<'col-sm-12'tr>>" +
                    "<'row'<'col-sm-5'i><'col-sm-7'p>>",

            });
        },
        resetContactFilter: function myfunction() {
            $("input:text").val("");
            Contact.loadContactTable();

        },
        addUpdateContact: function () {

            if (ValidateContact()) {
                var request = {
                    "FirstName": $("#FirstName").val(),
                    "LastName": $("#LastName").val(),
                    "Email": $("#Email").val(),
                    "Phone": $("#Phone").val(),
                    "Status": $("#Status").val(),
                    "ContactId": $("#ContactId").val()
                };

                $.ajax({
                    url: "/Contact/AddUpdate",
                    type: "POST",
                    datatype: "json",
                    data: { frmData: JSON.stringify(request) },
                    success: function (data) {
                        if (data.issuccess === true) {
                            alert(data.msg);
                            window.location.href = '/Contact/List/';
                        } else {
                            alert(data.msg);
                        }
                    },
                    failure: function (response) {

                    },
                    error: function (jqXHR, textStatus, errorThrown) {

                    },
                    complete: function (response) {

                    }
                });
            }

        },
        deleteContact: function (cid) {
            if (confirm("Are you sure you want to delete this?")) {
                $.ajax({
                    url: "/Contact/Delete",
                    type: "Get",
                    datatype: "json",
                    data: { id: cid },
                    success: function (data) {
                        if (data.issuccess === true) {
                            alert(data.msg);
                            window.location.href = '/Contact/List';
                        } else {
                            alert(data.msg);
                        }
                    },
                    failure: function (response) {

                    },
                    error: function (jqXHR, textStatus, errorThrown) {

                    },
                    complete: function (response) {

                    }
                });
            }
        }
    };
}();
$ && $(document).ready(function () {
    Contact.init();
    Contact.loadContactTable();

});