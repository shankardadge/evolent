﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Evolent.Models.ViewModels;
using Evolent.Services.Services;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Evolent.UI.Controllers
{
	/// <summary>
	/// Controller for basic opration regrding contact like add/adit/update/delete
	/// </summary>
	public class ContactController : Controller
	{
		IContactService ContactServiceProvider;
		JsonSerializerSettings _jsonSettings;
		public ContactController(IContactService contactService)
		{
			_jsonSettings = new JsonSerializerSettings
			{
				ReferenceLoopHandling = ReferenceLoopHandling.Ignore
			};
			ContactServiceProvider = contactService;
		}
		// GET: /<controller>/
		public IActionResult List()
		{
			return View();
		}
		/// <summary>
		/// Load listing data and return in json format 
		/// </summary>
		/// <param name="pageNo"></param>
		/// <param name="filter"></param>
		/// <returns></returns>
		public ActionResult LoadList(int pageNo, SearchContactModel filter)
		{

			var draw = HttpContext.Request.Form["draw"].FirstOrDefault();
			int pageSize = Convert.ToInt32(HttpContext.Request.Form["length"].FirstOrDefault());
			filter.PageSize = pageSize;
			filter.PageNo = pageNo;
			var result = ContactServiceProvider.List(filter);
			if (result.IsSuccess)
			{
				return Json(new { draw = draw, recordsFiltered = result.Response.TotalRecords, recordsTotal = result.Response.List, data = result.Response.List });
			}
			else
			{
				return Json(new { draw = "", recordsFiltered = 0, recordsTotal = 0, data = "" });
			}
		}

		/// <summary>
		/// Get action for add/update record
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		[HttpGet]
		public ActionResult AddUpdate(long? id)
		{
			ContactModel contactModel = new ContactModel();
			if (id == null || id == 0)
			{
				contactModel.Status = true;
			}
			else
			{
				var result = ContactServiceProvider.Get(id.Value);
				if (result.IsSuccess)
					contactModel = result.Response;
			}

			return View(contactModel);
		}

		/// <summary>
		/// Post Action for Add / update record
		/// </summary>
		/// <param name="frmData"></param>
		/// <returns></returns>
		[HttpPost]
		public ActionResult AddUpdate(string frmData)
		{
			ContactModel model = JsonConvert.DeserializeObject<ContactModel>(frmData, _jsonSettings);
			var result = ContactServiceProvider.AddUpdate(model);
			return Json(new { msg = result.Message, issuccess = result.IsSuccess });
		}
		/// <summary>
		/// Action for delete record
		/// </summary>
		/// <param name="id"></param>
		/// <returns></returns>
		[HttpGet]
		public ActionResult Delete(long id)
		{

			var result = ContactServiceProvider.Delete(id);
			return Json(new { msg = result.Message, issuccess = result.IsSuccess });
		}

	}
}
