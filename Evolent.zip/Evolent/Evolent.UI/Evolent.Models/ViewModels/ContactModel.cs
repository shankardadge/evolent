﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Evolent.Models.ViewModels
{

    /// <summary>
    /// Modeel class of contact
    /// </summary>
    public class ContactModel
    {
        /// <summary>
        /// Contact First Name of type string
        /// </summary>
        public string FirstName { get; set; }
        /// <summary>
        /// Contact Last Name of type string
        /// </summary>

        public string LastName { get; set; }
        /// <summary>
        /// Contact email of type string
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Contact phone number of type long and size 12
        /// </summary>

        public string Phone { get; set; }

        /// <summary>
        /// Status of contact of type bool
        /// </summary>
        public bool Status { get; set; }

        /// <summary>
        /// Primary Id of contact in database
        /// </summary>

        public long ContactId { get; set; }
		/// <summary>
		/// userTackingId
		/// </summary>
		public string UserTackingId { get; set; }

	}
}
