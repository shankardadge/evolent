﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Evolent.Models.ViewModels
{
    /// <summary>
    /// Common class for prepare view model
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ViewResponseModel<T>
    {
        /// <summary>
        /// Response is actual response need to bind on view
        /// </summary>
        public T Response { get; set; }
        /// <summary>
        /// Message need to show on view
        /// </summary>
        public string Message { get; set; }
        /// <summary>
        /// Is api response is successfull
        /// </summary>
        public bool IsSuccess { get; set; }
    }
}
