﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Evolent.Models.ViewModels
{
    /// <summary>
    /// Filter class for search contact 
    /// </summary>
    public class SearchContactModel
    {
        /// <summary>
        /// Contact email address filter
        /// </summary>
        public string ContactEmail { get; set; }
        /// <summary>
        /// Contact phone number filter
        /// </summary>
        public long ContactPhone { get; set; }

        /// <summary>
		/// Page number 
		/// </summary>
		public int PageNo { get; set; }
        /// <summary>
        /// No of records to be return per page
        /// </summary>
        public int PageSize { get; set; }
    }
}
