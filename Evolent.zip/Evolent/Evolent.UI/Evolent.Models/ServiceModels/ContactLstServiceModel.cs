﻿using Evolent.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Text;

namespace Evolent.Models.ServiceModels
{
    public class ContactLstServiceModel
    {
        public ContactLstServiceModel()
        {
            List = new List<ContactModel>();
        }
        public List<ContactModel> List { get; set; }
        public int TotalRecords { get; set; }
       
    }
}
