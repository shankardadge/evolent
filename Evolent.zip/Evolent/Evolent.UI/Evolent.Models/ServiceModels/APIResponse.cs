﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Evolent.Models.ServiceModels
{
    public class APIResponse<T>
    {
       
            /// <summary>
            /// API response object
            /// </summary>
            public T Response { get; set; }

            /// <summary>
            /// Success/Failure message
            /// </summary>
            public string Message { get; set; }
        
    }
}
