﻿using Evolent.DataService.ServiceMoldels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Evolent.DataService.Services
{
    /// <summary>
    /// Contact service class for basic curd opration
    /// like add/edit/delete/list
    /// </summary>
    public interface IContactService
	{

        /// <summary>
        /// Add/Update contact detail method defination
        /// </summary>
        /// <param name="contactModel"></param>
        /// <returns></returns>

        ObjectResult AddUpdate(ContactServiceModel contactServiceModel);
        /// <summary>
        /// Method for delete contact 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>

        ObjectResult Delete(long Id);
        /// <summary>
        /// Get contact list method defination
        /// </summary>
        /// <param name="searchContactModel"></param>
        /// <returns></returns>
        ObjectResult List(ContactRequest apiRequest);
        /// <summary>
        /// GEt contact detail method defination
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        ObjectResult Get(long Id);

    }
}
