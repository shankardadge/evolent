﻿using Amazon.Lambda.Core;
using Evolent.DataService.Models;
using Evolent.DataService.ServiceMoldels;
using LinqKit;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Threading.Tasks;

namespace Evolent.DataService.Services
{
	public class ContactService : IContactService
	{
        public ObjectResult Get(long Id)
        {
            APIResponse<ContactServiceModel> apiResponse = new APIResponse<ContactServiceModel>();
            try
            {
                using (var dataContext = new EvolentContext())
                {
                    if (Id > 0)
                    {
                        var ContactDetail = dataContext.UserContact.FirstOrDefault(x => x.Id == Id);
                        if (ContactDetail != null)
                        {
                          
                            apiResponse.Response = new ContactServiceModel()
                            {
                                ContactId= ContactDetail.Id,
                                Email= ContactDetail.Email,
                                FirstName= ContactDetail.FirstName,
                                LastName= ContactDetail.LastName,
                                Phone= ContactDetail.Phone,
                                Status= ContactDetail.Status.Value,
                            };
                            apiResponse.Message = "Contact detail featched successfully.";
                            ObjectResult obj = new ObjectResult(apiResponse);
                            obj.StatusCode = (int)HttpStatusCode.OK;
                            return obj;
                        }
                        else
                        {
                            apiResponse.Message = "No record found";
                            ObjectResult obj = new ObjectResult(apiResponse);
                            obj.StatusCode = (int)HttpStatusCode.NotFound;
                            return obj;
                        }
                    }
                    else
                    {

                        apiResponse.Message = "Invalid contact id";
                        ObjectResult obj = new ObjectResult(apiResponse);
                        obj.StatusCode = (int)HttpStatusCode.BadRequest;
                        return obj;
                    }
                }
            }
            catch (AggregateException aex)
            {
				LambdaLogger.Log(JsonConvert.SerializeObject(aex));
				string exMessage = "";
                foreach (var exItem in aex.InnerExceptions)
                {
                    exMessage = $"{exMessage} {exItem}";
                }
                apiResponse.Message = exMessage;
                ObjectResult obj = new ObjectResult(apiResponse);
                obj.StatusCode = (int)HttpStatusCode.InternalServerError;
                return obj;
            }
            catch (Exception ex)
            {
				//Log exception
				LambdaLogger.Log(JsonConvert.SerializeObject(ex));
				apiResponse.Message = "Error occurred getting contact detail";
                ObjectResult obj = new ObjectResult(apiResponse);
                obj.StatusCode = (int)HttpStatusCode.InternalServerError;
                return obj;
            }
        }

		/// <summary>
		/// Method for add and update contact details
		/// </summary>
		/// <param name="contactServiceModel"></param>
		/// <returns></returns>
		public ObjectResult AddUpdate(ContactServiceModel contactServiceModel)
		{
			APIResponse<long> apiResponse = new APIResponse<long>();
			try
			{
				if (contactServiceModel != null)
				{
					using (var dataContext = new EvolentContext())
					{
						if (contactServiceModel.ContactId > 0)
						{
							var UserExists = dataContext.UserContact.FirstOrDefault(x => x.Id == contactServiceModel.ContactId);
							if (UserExists != null)
							{
								UserExists.FirstName = contactServiceModel.FirstName;
								UserExists.LastName = contactServiceModel.LastName;
								UserExists.Email = contactServiceModel.Email;
								UserExists.Phone = contactServiceModel.Phone;
								UserExists.Status = contactServiceModel.Status;
								UserExists.ModifiedBy = contactServiceModel.UserTackingId;
								dataContext.SaveChanges();
								apiResponse.Response = UserExists.Id;
								apiResponse.Message = "Contact updated successfully.";
								ObjectResult obj = new ObjectResult(apiResponse);
								obj.StatusCode = (int)HttpStatusCode.OK;
								return obj;

							}
							else
							{
								apiResponse.Message = "No record found for update contact";
								ObjectResult obj = new ObjectResult(apiResponse);
								obj.StatusCode = (int)HttpStatusCode.NotFound;
								return obj;
							}
						}
						else
						{
							UserContact userContact = new UserContact()
							{
								FirstName = contactServiceModel.FirstName,
								LastName = contactServiceModel.LastName,
								Email = contactServiceModel.Email,
								Phone = contactServiceModel.Phone,
								Status = contactServiceModel.Status,
								CreatedBy = contactServiceModel.UserTackingId,
								ModifiedBy = contactServiceModel.UserTackingId
							};
							dataContext.Add(userContact);
							dataContext.SaveChanges();
							apiResponse.Response = userContact.Id;
							apiResponse.Message = "Contact added successfully.";
							ObjectResult obj = new ObjectResult(apiResponse);
							obj.StatusCode = (int)HttpStatusCode.OK;
							return obj;
						}
					}
				}
				else
				{
					apiResponse.Message = "Invalid request body";
					ObjectResult obj = new ObjectResult(apiResponse);
					obj.StatusCode = (int)HttpStatusCode.BadRequest;
					return obj;
				}
			}
			catch (ValidationException vex)
			{
				apiResponse.Message = vex.InnerException != null ? vex.InnerException.Message : vex.Message;
				ObjectResult obj = new ObjectResult(apiResponse);

				obj.StatusCode = (int)HttpStatusCode.InternalServerError;
				
		
				return obj;

			}
			catch (AggregateException aex)
			{
				string exMessage = "";
				foreach (var exItem in aex.InnerExceptions)
				{
					exMessage = $"{exMessage} {exItem}";
				}
				apiResponse.Message = exMessage;
				ObjectResult obj = new ObjectResult(apiResponse);
				obj.StatusCode = (int)HttpStatusCode.InternalServerError;
				
				return obj;
			}
			catch (DbUpdateException vex)
			{
				apiResponse.Message = vex.InnerException != null ? vex.InnerException.Message : vex.Message;
				ObjectResult obj = new ObjectResult(apiResponse);
				obj.StatusCode = (int)HttpStatusCode.InternalServerError;
				if (apiResponse.Message.Contains("Duplicate"))
				{
					obj.StatusCode = 409;
				}
				return obj;
			}
			catch (Exception ex)
			{
				apiResponse.Message = JsonConvert.SerializeObject(ex);
				ObjectResult obj = new ObjectResult(apiResponse);
				obj.StatusCode = (int)HttpStatusCode.InternalServerError;
				return obj;
			}

		}
		
        /// <summary>
        /// Return the list of contacts
        /// </summary>
        /// <param name="apiRequest"></param>
        /// <returns></returns>
		public ObjectResult List(ContactRequest apiRequest)
		{
            APIResponse<ListServiceModel<List<ContactServiceModel>>> apiResponse = new APIResponse<ListServiceModel<List<ContactServiceModel>>>();
			apiResponse.Response = new ListServiceModel<List<ContactServiceModel>>();

			try
			{
				apiRequest.PageNo = apiRequest.PageNo != 0 ? apiRequest.PageNo : 1;
				apiRequest.PageSize = apiRequest.PageSize != 0 ? apiRequest.PageSize : 20;
				var skip = apiRequest.PageSize * (apiRequest.PageNo - 1);
				Expression<Func<UserContact, bool>> bookingpredicate = PredicateBuilder.New<UserContact>(true);
				if (!string.IsNullOrWhiteSpace(apiRequest.ContactEmail))
				{
					bookingpredicate = bookingpredicate.And(x => x.Email == apiRequest.ContactEmail);
				}
				if (apiRequest.ContactPhone > 0)
				{
					bookingpredicate = bookingpredicate.And(x => x.Phone == apiRequest.ContactPhone);
				}
				using (var _dataContext = new EvolentContext())
				{
					var UserContactLst = _dataContext.UserContact.OrderByDescending(x => x.Id).Where(bookingpredicate);
					int totalRecords = UserContactLst.Count();
					UserContactLst = UserContactLst.Skip(skip).Take(apiRequest.PageSize);
					var responseData = UserContactLst.Select(x => new ContactServiceModel()
					{
						Email = x.Email,
						FirstName = x.FirstName,
						LastName = x.LastName,
						Phone = x.Phone,
						Status = x.Status.Value,
						ContactId=x.Id
					}).ToList();
					if (responseData.Count > 0)
					{
                        apiResponse.Response.List = responseData;
                        apiResponse.Response.TotalRecords = totalRecords;
                        apiResponse.Message = "Contact list featched successfully.";
						ObjectResult obj = new ObjectResult(apiResponse);
						obj.StatusCode = (int)HttpStatusCode.OK;
						return obj;
					}
					else
					{
					
						apiResponse.Message = "No data found.";
						ObjectResult obj = new ObjectResult(apiResponse);
						obj.StatusCode = (int)HttpStatusCode.NoContent;
						return obj;
					}

				}
			}
			catch (Exception ex)
			{
				//Log exception code is remaining 
				LambdaLogger.Log(JsonConvert.SerializeObject(ex));
				apiResponse.Message = ex.Message;
				ObjectResult obj = new ObjectResult(apiResponse);
				obj.StatusCode = (int)HttpStatusCode.InternalServerError;
				return obj;
			}
		}
        /// <summary>
		/// Method for delete contact details
		/// </summary>
		/// <param name="Id"></param>
		/// <returns></returns>
		public ObjectResult Delete(long Id)
        {
            APIResponse<bool> apiResponse = new APIResponse<bool>();
            try
            {
                using (var dataContext = new EvolentContext())
                {
                    if (Id > 0)
                    {
                        var UserExists = dataContext.UserContact.FirstOrDefault(x => x.Id == Id);
                        if (UserExists != null)
                        {
                            dataContext.UserContact.Remove(UserExists);
                            dataContext.SaveChanges();
                            apiResponse.Response = true;
                            apiResponse.Message = "Contact deleted successfully.";
                            ObjectResult obj = new ObjectResult(apiResponse);
                            obj.StatusCode = (int)HttpStatusCode.OK;
                            return obj;
                        }
                        else
                        {
                            apiResponse.Message = "No record found for delete contact";
                            ObjectResult obj = new ObjectResult(apiResponse);
                            obj.StatusCode = (int)HttpStatusCode.NotFound;
                            return obj;
                        }
                    }
                    else
                    {

                        apiResponse.Message = "Invalid contact id";
                        ObjectResult obj = new ObjectResult(apiResponse);
                        obj.StatusCode = (int)HttpStatusCode.BadRequest;
                        return obj;
                    }
                }
            }
            catch (ValidationException vex)
            {
				//Log exception code is remaining 
				LambdaLogger.Log(JsonConvert.SerializeObject(vex));
				apiResponse.Message = vex.Message;
                ObjectResult obj = new ObjectResult(apiResponse);
                obj.StatusCode = (int)HttpStatusCode.InternalServerError;
				LambdaLogger.Log(JsonConvert.SerializeObject(vex));
				return obj;

            }
            catch (AggregateException aex)
            {
                //Log exception code is remaining 
                string exMessage = "";
                foreach (var exItem in aex.InnerExceptions)
                {
                    exMessage = $"{exMessage} {exItem}";
                }
                apiResponse.Message = exMessage;
                ObjectResult obj = new ObjectResult(apiResponse);
                obj.StatusCode = (int)HttpStatusCode.InternalServerError;
				LambdaLogger.Log(JsonConvert.SerializeObject(aex));
				return obj;
            }
            catch (Exception ex)
            {
				//Log exception code is remaining 
				LambdaLogger.Log(JsonConvert.SerializeObject(ex));
				apiResponse.Message = ex.Message;
                ObjectResult obj = new ObjectResult(apiResponse);
                obj.StatusCode = (int)HttpStatusCode.InternalServerError;

                return obj;
            }

        }



    }
}
