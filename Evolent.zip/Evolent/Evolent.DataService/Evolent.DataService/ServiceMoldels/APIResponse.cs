﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Evolent.DataService.ServiceMoldels
{
	/// <summary>
	/// Common API response class
	/// </summary>
	/// <typeparam name="T"></typeparam>
	public class APIResponse<T>
	{
		/// <summary>
		/// API response object
		/// </summary>
		public T Response { get; set; }

		/// <summary>
		/// Success/Failure message
		/// </summary>
		public string Message { get; set; }
	}
}
