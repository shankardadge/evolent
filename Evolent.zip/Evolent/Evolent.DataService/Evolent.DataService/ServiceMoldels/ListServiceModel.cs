﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Evolent.DataService.ServiceMoldels
{
    public class ListServiceModel<T>
    {
        /// <summary>
		///  list object
		/// </summary>
		public T List { get; set; }
        /// <summary>
        /// Total number of records exists in database
        /// </summary>
        public int TotalRecords { get; set; }

    }
}
