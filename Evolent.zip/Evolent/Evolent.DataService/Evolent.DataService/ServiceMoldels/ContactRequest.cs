﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Evolent.DataService.ServiceMoldels
{
    /// <summary>
    /// Filter class to search contact
    /// </summary>
	public class ContactRequest
	{
		/// <summary>
		/// Page number 
		/// </summary>
		public int PageNo { get; set; }
		/// <summary>
		/// No of records to be return per page
		/// </summary>
		public int PageSize { get; set; }
        /// <summary>
        /// Contact email id
        /// </summary>

		public string ContactEmail { get; set; }
        /// <summary>
        /// Contact phone number
        /// </summary>

		public long ContactPhone { get; set; }

	}
}
