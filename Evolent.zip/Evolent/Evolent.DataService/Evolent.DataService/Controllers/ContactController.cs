﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Evolent.DataService.ServiceMoldels;
using Evolent.DataService.Services;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Evolent.DataService.Controllers
{
	[Route("[controller]")]
	public class ContactController : Controller
	{
		IContactService contactService;
		public ContactController(IContactService service)
		{
			contactService = service;
		}
		// GET: /<controller>/
		[Route("list")]
		[HttpPost]
		public IActionResult List([FromBody]ContactRequest contactRequest)
		{
			return contactService.List(contactRequest);
		
		}
		// POST api/values
		[Route("addupdate")]
		[HttpPost]
		public IActionResult AddUpdate([FromBody]ContactServiceModel contactServiceModel)
		{
			return contactService.AddUpdate(contactServiceModel);
		}

		// DELETE api/values/5
		[HttpGet]
		[Route("delete")]
		public IActionResult delete(int id)
		{
			return contactService.Delete(id);
		}

        // DELETE api/values/5
        [HttpGet]
        [Route("get")]
        public IActionResult get(int id)
        {
            return contactService.Get(id);
        }
    }
}
