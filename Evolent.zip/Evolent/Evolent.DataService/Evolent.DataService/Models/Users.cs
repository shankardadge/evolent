﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Evolent.DataService.Models
{
    [Table("users")]
    public partial class Users
    {
        [Column("id", TypeName = "mediumint unsigned")]
        public uint Id { get; set; }
        [Column("title", TypeName = "varchar(255)")]
        public string Title { get; set; }
        [Column("first_name", TypeName = "varchar(255)")]
        public string FirstName { get; set; }
        [Column("last_name", TypeName = "varchar(255)")]
        public string LastName { get; set; }
        [Column("phone", TypeName = "varchar(100)")]
        public string Phone { get; set; }
        [Column("city", TypeName = "varchar(50)")]
        public string City { get; set; }
        [Column("zip", TypeName = "varchar(10)")]
        public string Zip { get; set; }
        [Column("updated_date", TypeName = "datetime")]
        public DateTime? UpdatedDate { get; set; }
        [Column("registered_date", TypeName = "datetime")]
        public DateTime? RegisteredDate { get; set; }
        [Column("removed_date", TypeName = "datetime")]
        public DateTime? RemovedDate { get; set; }
        [Column("active", TypeName = "tinyint(1)")]
        public sbyte? Active { get; set; }
        [Column("manager", TypeName = "int(11)")]
        public int? Manager { get; set; }
        [Column("site", TypeName = "int(11)")]
        public int? Site { get; set; }
        [Column("image", TypeName = "int(11)")]
        public int? Image { get; set; }
        [Column("shift_start", TypeName = "time")]
        public TimeSpan? ShiftStart { get; set; }
        [Column("shift_end", TypeName = "time")]
        public TimeSpan? ShiftEnd { get; set; }
    }
}
