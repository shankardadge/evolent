﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Evolent.DataService.Models
{
    [Table("User_Contact")]
    public partial class UserContact
    {
        [Column(TypeName = "bigint(20)")]
        public long Id { get; set; }
        [Required]
        [Column("First_Name", TypeName = "varchar(150)")]
        public string FirstName { get; set; }
        [Required]
        [Column("Last_Name", TypeName = "varchar(150)")]
        public string LastName { get; set; }
        [Required]
        [Column(TypeName = "varchar(150)")]
        public string Email { get; set; }
        [Column(TypeName = "bigint(11)")]
        public long Phone { get; set; }
        [Column(TypeName = "bit(1)")]
        public bool? Status { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedOn { get; set; }
        [Column(TypeName = "varchar(150)")]
        public string ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedOn { get; set; }
        [Column(TypeName = "varchar(150)")]
        public string CreatedBy { get; set; }
    }
}
