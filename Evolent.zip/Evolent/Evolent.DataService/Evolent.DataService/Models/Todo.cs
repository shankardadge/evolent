﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Evolent.DataService.Models
{
    [Table("todo")]
    public partial class Todo
    {
        [Column("id", TypeName = "int(10)")]
        public int Id { get; set; }
        [Required]
        [Column("item", TypeName = "varchar(255)")]
        public string Item { get; set; }
        [Column("done", TypeName = "tinyint(1)")]
        public sbyte Done { get; set; }
        [Column("priority", TypeName = "int(11)")]
        public int Priority { get; set; }
    }
}
