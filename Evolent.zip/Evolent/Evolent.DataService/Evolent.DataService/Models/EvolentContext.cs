﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Evolent.DataService.Models
{
    public partial class EvolentContext : DbContext
    {
        public EvolentContext()
        {
        }

        public EvolentContext(DbContextOptions<EvolentContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Todo> Todo { get; set; }
        public virtual DbSet<UserContact> UserContact { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseMySql("Server=mcopper.cpgblovi4cp6.ap-southeast-1.rds.amazonaws.com;Database=Datatable;user id=u828672579_deva;password=fuccpYas9Z7t;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Todo>(entity =>
            {
                entity.Property(e => e.Done).HasDefaultValueSql("'0'");

                entity.Property(e => e.Item).HasDefaultValueSql("''");

                entity.Property(e => e.Priority).HasDefaultValueSql("'1'");
            });

            modelBuilder.Entity<UserContact>(entity =>
            {
                entity.Property(e => e.CreatedOn).HasDefaultValueSql("'CURRENT_TIMESTAMP'");

                entity.Property(e => e.ModifiedOn).HasDefaultValueSql("'CURRENT_TIMESTAMP'");
            });
        }
    }
}
