﻿using Evolent.DataService.ServiceMoldels;
using Evolent.DataService.Services;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Evolent.Test
{
	public class FunctionTest
	{
		
		[Fact]
		public void CreateAuditLog_Success()
		{
			ContactService contactService = new ContactService();

			var result =contactService.List(new ContactRequest()
			{
				ContactEmail="",
				ContactPhone=0,
				PageNo=1,
				PageSize=20
			});
		
			Assert.True(result != null);
		}

		[Fact]
		public void CreateContact_Success()
		{
			ContactService contactService = new ContactService();

			var result = contactService.AddUpdate(new ContactServiceModel()
			{
				ContactId=1,
				Email="reddys1000@gmail.com",
				FirstName="Shankar",
				LastName="Dadge",
				Phone=9699788888,
				Status=true,
				UserTackingId="test"

			});

			Assert.True(result != null);
		}
	}
}
